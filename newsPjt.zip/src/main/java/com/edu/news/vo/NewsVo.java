package com.edu.news.vo;

public class NewsVo {
	
	private int n_no;
	private String n_title;
	private String n_title_href;
	private String n_photo_name;
	private String n_article;
	private String n_publisher;
	private String n_reg_date;
	
	// getter&setter 자동화 프레임워크 있음 > lombok 
	public int getN_no() {
		return n_no;
	}
	public void setN_no(int n_no) {
		this.n_no = n_no;
	}
	public String getN_title() {
		return n_title;
	}
	public void setN_title(String n_title) {
		this.n_title = n_title;
	}
	public String getN_title_href() {
		return n_title_href;
	}
	public void setN_title_href(String n_title_href) {
		this.n_title_href = n_title_href;
	}
	public String getN_photo_name() {
		return n_photo_name;
	}
	public void setN_photo_name(String n_photo_name) {
		this.n_photo_name = n_photo_name;
	}
	public String getN_article() {
		return n_article;
	}
	public void setN_article(String n_article) {
		this.n_article = n_article;
	}
	public String getN_publisher() {
		return n_publisher;
	}
	public void setN_publisher(String n_publisher) {
		this.n_publisher = n_publisher;
	}
	public String getN_reg_date() {
		return n_reg_date;
	}
	public void setN_reg_date(String n_reg_date) {
		this.n_reg_date = n_reg_date;
	}
	

	
	
}
